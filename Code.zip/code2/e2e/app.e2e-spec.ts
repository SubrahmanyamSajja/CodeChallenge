import { Code1Page } from './app.po';

describe('code1 App', function() {
  let page: Code1Page;

  beforeEach(() => {
    page = new Code1Page();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
