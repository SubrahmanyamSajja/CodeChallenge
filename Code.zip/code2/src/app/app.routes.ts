// Imports
// Deprecated import
// import { provideRouter, RouterConfig } from '@angular/router';
import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { movieRoutes }    from './movies/movie.routes';
import {profileRoutes} from './profile/profile.routes';
import {cardRoutes} from './cards/cards.routes';

// Route Configuration
export const routes: Routes = [
  {
    path: '',
    redirectTo: '/favourite-movie',
    pathMatch: 'full'
  },
    // Add other routes form a different file
  ...movieRoutes,
  ...profileRoutes,
  ...cardRoutes,
];


export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
