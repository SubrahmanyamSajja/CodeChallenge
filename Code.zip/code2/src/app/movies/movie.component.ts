import 'rxjs/add/operator/switchMap';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Response }    from '@angular/http';
import { MovieService }  from './movie.service';

@Component({
  templateUrl:'./movie.component.html',
})
export class MovieComponent implements OnInit {
  movie: any={};
  casts: any={};
  castimageBasePath:string='https://image.tmdb.org/t/p/w132_and_h132_bestv2';
  private selectedId: number;

  constructor(
    private service: MovieService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
      this.service.getMovieById().subscribe((res:Response) => this.movie = res.json());
      this.service.getMovieCasts().subscribe((res:Response) => this.casts = res.json());
  }
}

