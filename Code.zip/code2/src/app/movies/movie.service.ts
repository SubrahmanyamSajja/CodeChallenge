// Imports
import { Injectable }    from '@angular/core';
import { Http, Response }    from '@angular/http';
import { Observable }    from 'rxjs/Observable';

@Injectable()
export class MovieService {
  
  // Class constructor with http injected
  constructor(private _http:Http) { }
  
  private _apiToken:string ='691358b1f822d21240cc5e229c22cc21';
  
  private _favouriteMovieId='135397';
  
  // Base URL for Petfinder API
  private _movieDetailsUrl = 'https://api.themoviedb.org/3/movie/{MOVIEID}?api_key={API_TOKEN}&language=en-US';
  private _moviecastUrl='https://api.themoviedb.org/3/movie/{MOVIEID}/credits?api_key={API_TOKEN}'
  private _profileUrl='https://api.themoviedb.org/3/person/{PROFIEID}?api_key={API_TOKEN}&language=en-US'
  // Get a Favourite Movie Details
  getMovieById() {
      var tempUrl=this._movieDetailsUrl.replace('{MOVIEID}',this._favouriteMovieId).replace('{API_TOKEN}',this._apiToken);
      return this._http.get(tempUrl);
  }
  getMovieCasts(){
      var tempUrl=this._moviecastUrl.replace('{MOVIEID}',this._favouriteMovieId).replace('{API_TOKEN}',this._apiToken);
      return this._http.get(tempUrl);
  }
  getProfile(id:number){
      var tempUrl=this._profileUrl.replace('{PROFIEID}',id.toString()).replace('{API_TOKEN}',this._apiToken);
      return this._http.get(tempUrl);
  }

}
