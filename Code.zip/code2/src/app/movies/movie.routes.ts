// Imports
// Deprecated import
// import { RouterConfig } from '@angular/router';
import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MovieComponent }    from './movie.component';

// Route Configuration
export const movieRoutes: Routes = [
  { path: 'favourite-movie', component: MovieComponent },
];

@NgModule({
  imports: [
    RouterModule.forChild(movieRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class movieRoutingModule { }