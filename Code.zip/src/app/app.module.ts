import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { MovieComponent } from './movies/movie.component';
import { ProfileComponent } from './profile/profile.component';
import { CardComponent } from './cards/cards.component';
import { MaterialModule } from '@angular/material';
import { routing } from './app.routes';
import { MovieService }          from './movies/movie.service';
import { CardService }          from './cards/cards.service';

import 'hammerjs';

@NgModule({
  declarations: [
    AppComponent,MovieComponent,ProfileComponent,CardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MaterialModule.forRoot(),
    routing
  ],
  providers: [MovieService,CardService],
  bootstrap: [AppComponent]
})
export class AppModule { }


