// Imports
import { Injectable }    from '@angular/core';
import { Http, Response }    from '@angular/http';
import { Observable }    from 'rxjs/Observable';

@Injectable()
export class CardService {
  
  // Class constructor with http injected
  constructor(private _http:Http) { }

  // Get a Favourite Movie Details
  getCardId() {
      return this._http.get('https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=2');
  }
  checkResult(cardId:string){
      let temp:string='https://deckofcardsapi.com/api/deck/{CARDID}/draw/?count=2';
      temp=temp.replace('{CARDID}',cardId);
      return this._http.get(temp);
  }

}
