import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CardComponent }    from './cards.component';

// Route Configuration
export const cardRoutes: Routes = [
  { path: 'deck', component: CardComponent },
];

@NgModule({
  imports: [
    RouterModule.forChild(cardRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class movieRoutingModule { }