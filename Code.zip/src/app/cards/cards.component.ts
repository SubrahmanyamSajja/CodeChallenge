// TODO SOMEDAY: Feature Componetized like CrisisCenter
import 'rxjs/add/operator/switchMap';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Response }    from '@angular/http';
import { CardService }  from './cards.service';

@Component({
  templateUrl:'./cards.component.html',
})
export class CardComponent implements OnInit {
  mode: string='High';
  img1: string='assets/card_back.png';
  img2: string='assets/card_back.png';
  cardDetails:any={};
  cardsDetails:any={};
  castimageBasePath:string='https://image.tmdb.org/t/p/w132_and_h132_bestv2';
  showPlayAgain:boolean = false;
  private selectedId: number;

  constructor(
    private service: CardService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
      this.service.getCardId().subscribe((res:Response) => this.cardDetails = res.json());
  }

  result:string='Please click on one card to check win /loose'

  playAgain(){
      this.service.getCardId().subscribe((res:Response) => this.cardDetails = res.json());
      this.result='Please click on one card to check win /loose'
      this.mode='High';
      this.img1='assets/card_back.png';
      this.img2='assets/card_back.png';
      this.cardDetails={};
      this.showPlayAgain=false;
  }
  checkResult(clickedOn:Number){
    
     this.service.checkResult(this.cardDetails.deck_id).subscribe(
       (res:Response) => { this.cardsDetails = res.json();
         if(this.cardsDetails.cards[0].value==this.cardsDetails.cards[1].value){
            this.checkResult(clickedOn);
         } else {
            this.img1=this.cardsDetails.cards[0].image;
            this.img2=this.cardsDetails.cards[1].image;
            let notClickedOn= (clickedOn==0)?1:0;
            var replaces={'A':1,'2':2,'3':3,'4':4,'5':5,'6':'6','7':7,'8':8,'9':9,'10':10,'QUEEN':12,'KING':13,'JACK':11};
            let clickedValue=  replaces[this.cardsDetails.cards[clickedOn.toString()].value];
            let notClickedValue=  replaces[this.cardsDetails.cards[notClickedOn.toString()].value];
            if((this.mode=='High' && clickedValue>notClickedValue ) || (this.mode=='Low' && clickedValue<notClickedValue)){
                this.result='You Won ! ';
            } else {
              this.result='Better Luck Next Time ';
            }
            this.showPlayAgain=true;
         }
       });
  }

}

