import {Component, Optional} from '@angular/core';
import {MdDialog, MdDialogRef, MdSnackBar} from '@angular/material';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // Tell component to use router directives
})
export class AppComponent {
  title = 'app works!';
  isDarkTheme:boolean=true;
  /*
  constructor(public dialog:MdDialog, public vcr:ViewContainerRef){}
  
  openDialog() {
    const config=new MdDialogConfig();
    config.viewContainerRef=this.vcr;
    this.dialog.open(SettingsDialog,config);
  }
*/

}
