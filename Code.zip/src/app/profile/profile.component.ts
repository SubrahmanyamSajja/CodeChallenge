// TODO SOMEDAY: Feature Componetized like CrisisCenter
import 'rxjs/add/operator/switchMap';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Response }    from '@angular/http';
import { MovieService }  from '../movies/movie.service';

@Component({
  templateUrl:'./profile.component.html'
})
export class ProfileComponent implements OnInit {
  profile: any={};
  imageBasePath:string='https://image.tmdb.org/t/p/w300_and_h450_bestv2';
  private profileId: number;

  constructor(
    private service: MovieService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
        let id = params['profileId'];
       // Retrieve Profile with profileId route param
        this.service.getProfile(id).subscribe(profile => this.profile = profile.json());
    });
  }
}

